using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Starship : AgentObject
{
    [SerializeField] float movementSpeed;
    [SerializeField] float rotationSpeed;
    [SerializeField] float whiskerLength; //How long each whisker is
    [SerializeField] float whiskerAngle;//The angle from the front of the agent
    [SerializeField] float avoidanceWeight;//How much we should turn away from the obstacle
    private Rigidbody2D rb;

    new void Start() // Note the new.
    {
        base.Start(); // Explicitly invoking Start of AgentObject.
        Debug.Log("Starting Starship.");
        rb = GetComponent<Rigidbody2D>();
    }

    void FixedUpdate()
    {
        if (TargetPosition != null)
        {
           
            SeekForward();
            AvoidObstacles();
            // Add call to AvoidObstacles.
            //
        }
    }

    private void AvoidObstacles()
    {
        // Cast whiskers to detect obstacles.
        bool hitCenter = CastWhisker(0f, whiskerLength, Color.red);
        bool hitLeft = CastWhisker(90f, whiskerLength, Color.magenta);
        bool hitRight = CastWhisker(270f, whiskerLength* 0.5f, Color.blue);
        bool hitBack = CastWhisker(180f, whiskerLength, Color.black);
        //Add a second parameter to Castwhisker that is a color object
        //when you invoke Castwhisker, pass as teh second parameter a color value
        //such as Color.red Make eachh whisker a unique color value

        // Adjust rotation based on detected obstacles.
        if (hitCenter)
        {
            RotateClockwise();
        }
           
        else if (hitLeft)
        {
            RotateClockwise();
        }
            
        else if (hitRight)
        {
            RotateCounterClockwise();
        }
            
    }

    private void RotateCounterClockwise()
    {
        // Rotate counterclockwise based on rotationSpeed and a weight.
        transform.Rotate(Vector3.forward, rotationSpeed * avoidanceWeight * Time.fixedDeltaTime);
    }

    private void RotateClockwise()
    {
        // Rotate clockwise based on rotationSpeed and a weight.
        // 
    }

    private bool CastWhisker(float angle, float whiskerLength, Color rayColor)
    {
        bool hitResult = false;
        //Define a colour object to store the colour of the ray

        //Calculate direction of the whisker
        Vector2 whiskerDirection = Quaternion.Euler(0f, 0f, angle)*transform.up;
        //Cast a ray in the whisker direction
        RaycastHit2D hitData = Physics2D.Raycast(transform.position, whiskerDirection, whiskerLength);
       //check hitData to see if ray hit obstacle
       if(hitData.collider != null)
        {
            Debug.Log("Obstacle detected");
            rayColor = Color.green;
            hitResult = true;
        }
        //Visualize the ray with the debug function
        Debug.DrawRay(transform.position, whiskerDirection* whiskerLength, rayColor);
        return hitResult;
    }

    private void SeekForward() // A seek with rotation to target but only moving along forward vector.
    {
        // Calculate direction to the target.
        Vector2 directionToTarget = (TargetPosition - transform.position).normalized;

        // Calculate the angle to rotate towards the target.
        float targetAngle = Mathf.Atan2(directionToTarget.y, directionToTarget.x) * Mathf.Rad2Deg + 90.0f; // Note the +90 when converting from Radians.

        // Smoothly rotate towards the target.
        float angleDifference = Mathf.DeltaAngle(targetAngle, transform.eulerAngles.z);
        float rotationStep = rotationSpeed * Time.fixedDeltaTime;
        float rotationAmount = Mathf.Clamp(angleDifference, -rotationStep, rotationStep);
        transform.Rotate(Vector3.forward, rotationAmount);

        // Move along the forward vector using Rigidbody2D.
        rb.velocity = transform.up * (movementSpeed*Time.fixedDeltaTime);
    }
    //Make the arrive function here
    //invoke SeekForward() for the first part of that method
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Target")
        {
            GetComponent<AudioSource>().Play();
            // What is this!?! Didn't you learn how to create a static sound manager last week in 1017?
        }
    }
}
